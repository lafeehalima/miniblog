<?php 

require 'connection.php';

function getAllArticles(){
    $db = dbconnect();
    $query = $db->query('SELECT * FROM articles');
    $results = $query->fetchAll(PDO::FETCH_ASSOC);
    return $results;
}
