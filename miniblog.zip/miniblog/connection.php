<?php

// Création de l’objet PDO
function dbconnect() {
    try{
        $db = new PDO('mysql:host=localhost;dbname=blog;charset=utf8', 'root', 'x3nd2VQ3',[PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        echo 'Vous êtes connecté';
        return $db;
    }catch (Exception $e){
        die('Erreur : ' . $e->getMessage());
    }
}