<?php 

include 'partials/head.php'; 
require 'connection.php';
include 'partials/footer.php';