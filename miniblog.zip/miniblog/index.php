<?php 

include 'partials/head.php';
require 'functions.php';
$articles = getAllArticles();
foreach($articles as $article){?>
    <!-- echo '<h2>'.$article['title'].'</h2>';-->
    <h2><?php echo $article['title']?></h2>
<?php } 
include 'partials/footer.php';
    
